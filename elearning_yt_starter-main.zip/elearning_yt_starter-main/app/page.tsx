import React from "react";

const HomePage = () => {
  return <div className="text-4xl text-red-700">HomePage</div>;
};

export default HomePage;
