export const navLinks = [
  {
    id: 1,
    url: "#",
    label: "Home",
  },
  {
    id: 2,
    url: "#",
    label: "About",
  },
  {
    id: 3,
    url: "#",
    label: "Courses",
  },
  {
    id: 4,
    url: "#",
    label: "Testimonial",
  },
  {
    id: 5,
    url: "#",
    label: "Blog",
  },
  {
    id: 6,
    url: "#",
    label: "Contact",
  },
];
